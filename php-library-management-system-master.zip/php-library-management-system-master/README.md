# Library Management system build using PHP

![Image](http://i1.wp.com/www.arjunsk.com/wp-content/uploads/2016/02/Untitled-2-1.png)

The basic functionalities include

1. adding Bookcase such as ‘bedside bookcase’ or ‘hallway bookcase’, with shelf count and capacity
2. adding books to the bookcase
3. deleting Bookcase (puts the books to the heap)
4. Display your profile info
   
Read my tutorial here : http://www.arjunsk.com/php/php-library-management-system/
